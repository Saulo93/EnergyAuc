angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

 
  $scope.loginData = {};

  
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  
  $scope.login = function() {
    $scope.modal.show();
  };

  
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: 'Leilão brasileiro ', id: 1 },
    { title: 'Leilão inglês', id: 2 }
    
    
  ];
})

.controller('otherCtrl', function($scope) {
  $scope.others = [
    { title: 'Calculadora ', id: 1 },
    { title: 'Gráficos', id: 2 }
    
    
  ];
})
.controller('PlaylistCtrl', function($scope, $stateParams) {
});

function RouteCtrl($route) {

    var self = this;

    $route.when('browse', {template:'templates/search.html'});
    $route.otherwise({redirectTo:'/playlists'});
  }
